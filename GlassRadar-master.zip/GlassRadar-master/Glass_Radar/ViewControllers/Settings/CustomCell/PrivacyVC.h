//
//  PrivacyVC.h
//  Glass_Radar
//
//  Created by Mina on 3/19/13.
//  Copyright (c) 2013 Bamboo Rocket Apps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PrivacyVC : UIViewController <UIWebViewDelegate>

{
    UIWebView *webView;
}

@end
