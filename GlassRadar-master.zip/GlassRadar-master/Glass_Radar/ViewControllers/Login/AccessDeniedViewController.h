//
//  AccessDeniedViewController.h
//  Glass_Radar
//
//  Created by Nirmalsinh Rathod on 1/24/13.
//  Copyright (c) 2013 Bamboo Rocket Apps. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AccessDeniedViewController : UIViewController
{
    
    IBOutlet UIImageView *imgBG;
}

- (IBAction)btnPhoneClick:(id)sender;
@end
