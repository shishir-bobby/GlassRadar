#import "AbstractLayoutView.h"

@interface VLayoutView : AbstractLayoutView
{
}

@end
